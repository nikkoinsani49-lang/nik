-- Face verification profile for QR attendance.
-- Stores 5 x 128-value face descriptors captured during admin enrollment.
ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS face_descriptors JSONB;

COMMENT ON COLUMN public.students.face_descriptors IS
  'Array of face-api descriptors captured during enrollment. Used only to gate QR attendance.';
