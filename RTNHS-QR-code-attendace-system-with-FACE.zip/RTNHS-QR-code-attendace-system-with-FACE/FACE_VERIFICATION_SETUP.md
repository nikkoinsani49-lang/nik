# RTNHS Face + QR Attendance Integration

## What changed

The scanner now uses this sequence:

**Face verification -> QR verification -> attendance -> SMS**

A QR code is accepted only when the live face matches the same enrolled student. A QR belonging to a different student is rejected as a **FACE / QR MISMATCH**.

### Added
- Five-angle face enrollment (front, left, right, up, down) in Admin > Student Management.
- Persistent `students.face_descriptors` JSONB storage in Supabase.
- Live face matching in the existing Scanner phone face camera.
- Two consecutive matching frames are required before the QR gate opens.
- Existing QR scanning, attendance logging, verification photos, SMS, offline queue, and ESP32-CAM flow remain intact.

## Supabase migration

Run the new migration:

`supabase/migrations/20261006000000_add_face_descriptors.sql`

It adds:

`students.face_descriptors JSONB`

## First-time enrollment

1. Apply the migration.
2. Start the app over HTTPS (or localhost) because browser camera access requires a secure context.
3. Log in as admin.
4. Open **Student Management**.
5. Select a section.
6. Press **Enroll Face** beside a student.
7. Capture all five guided poses.
8. Repeat for every student who will use face-gated attendance.

## Scanner behavior

1. Open the scanner and authenticate the section PIN.
2. The phone face camera waits for a recognized enrolled student.
3. After two matching detections, the scanner displays **FACE VERIFIED — SCAN YOUR QR**.
4. Scan the student's QR.
5. If the QR belongs to the verified face, the existing attendance pipeline continues.
6. If it belongs to another student, attendance is not recorded and the scanner shows **FACE / QR MISMATCH**.
7. After a successful scan, the face gate resets for the next student.

## Face model hosting

The integration uses the same browser/CDN approach as the supplied prototype:

- `@vladmandic/face-api` from jsDelivr
- Models from `https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/`

The face descriptors are stored as numerical vectors; no enrollment photo is stored by this feature.

## Matching threshold

The current distance threshold is `0.52` in `src/lib/faceVerification.ts`.

If the school's camera/lighting produces too many false rejects, this can be raised carefully. If it produces false matches, lower it. Test with real enrolled students before deployment.

## Important deployment note

This feature is an attendance anti-sharing measure, not a high-security biometric authentication system. Camera angle, lighting, masks, image quality, and similar faces can affect matching. Keep the existing QR and section controls as part of the attendance workflow.
