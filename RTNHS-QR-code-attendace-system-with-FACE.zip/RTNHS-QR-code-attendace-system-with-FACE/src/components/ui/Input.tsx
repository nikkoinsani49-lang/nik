import * as React from "react"
import { cn } from "../../lib/utils"

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex min-h-[44px] w-full rounded-md border px-3 py-1 text-sm transition-colors bg-[var(--input-bg)] border-[var(--input-border)] text-[var(--body-text)] placeholder:text-[var(--sidebar-muted)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--input-focus)] focus-visible:border-[var(--input-focus)] disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
