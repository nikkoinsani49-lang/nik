const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/'
const MATCH_THRESHOLD = 0.52
let modelsReady = false
let modelsPromise: Promise<void> | null = null
export type FaceDescriptor = number[]
export async function loadFaceModels(): Promise<void> {
  if (modelsReady) return
  if (modelsPromise) return modelsPromise
  modelsPromise = (async () => {
    if (typeof faceapi === 'undefined') throw new Error('Face verification library failed to load.')
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ])
    modelsReady = true
  })()
  try { await modelsPromise } catch (e) { modelsPromise = null; throw e }
}
export async function descriptorFromVideo(video: HTMLVideoElement): Promise<FaceDescriptor | null> {
  if (!video.videoWidth || !video.videoHeight) return null
  await loadFaceModels()
  const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 224, scoreThreshold: 0.5 })
  const result = await faceapi.detectSingleFace(video, options).withFaceLandmarks().withFaceDescriptor()
  return result?.descriptor ? Array.from(result.descriptor) : null
}
export function faceDistance(a: FaceDescriptor, b: FaceDescriptor): number { return faceapi.euclideanDistance(new Float32Array(a), new Float32Array(b)) }
export function findBestFaceMatch(probe: FaceDescriptor, students: Array<{ id: string; face_descriptors?: FaceDescriptor[] | null }>): { studentId: string; distance: number } | null {
  let best: { studentId: string; distance: number } | null = null
  for (const student of students) for (const saved of student.face_descriptors || []) {
    const distance = faceDistance(probe, saved)
    if (!best || distance < best.distance) best = { studentId: student.id, distance }
  }
  return best && best.distance <= MATCH_THRESHOLD ? best : null
}
export const FACE_MATCH_THRESHOLD = MATCH_THRESHOLD
