# Face verification merge

- Added `src/lib/faceVerification.ts`
- Added `src/components/admin/FaceEnrollment.tsx`
- Added `students.face_descriptors` migration
- Extended `CameraStreamHandle` with `getFaceVideo()`
- Added live face gate and QR-to-face identity check to `ScannerTerminal`
- Added face verification CDN script to `index.html`
- Added setup documentation
